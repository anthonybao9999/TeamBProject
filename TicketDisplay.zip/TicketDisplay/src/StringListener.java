//String Listener Interface
public interface StringListener {
	public void textEmitted(String text);
	
}

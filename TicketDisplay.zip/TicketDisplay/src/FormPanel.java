import java.awt.*;


import javax.swing.*;
import javax.swing.border.Border;

//Create a FromPanel class from JPanel Library
public class FormPanel extends JPanel{
	
	private JLabel nameLabel; // Create Label Instance for the name
	private JLabel idNumberLabel;// Create label Instance for Number
	private JLabel reportedProblemLabel;
	private JLabel dateStartedLabel;
	private JLabel statusLabel;
	private JLabel priorityLabel;
	private	JTextField nameField;	// Create Instance Object
	private JTextField idNumberField; 
	private JTextField reportedProblemField;
	private JTextField dateStartedField;
	private JTextField statusField;
	private JTextField priorityField;
	private JButton submitBtn; //Create Instance Object
	
	public FormPanel() {
	// Set size for Form Panel
		Dimension dim = getPreferredSize();
		dim.width = 250;
		setPreferredSize(dim);
		
		nameLabel = new JLabel("Full name:"); // create nameLabel Object
		idNumberLabel = new JLabel("ID number:"); //create Number Object
		reportedProblemLabel = new JLabel("Reported Problem:");
		dateStartedLabel = new JLabel("Date Started:");
		statusLabel = new JLabel("Label:");
		priorityLabel = new JLabel("Priority:");
		nameField = new JTextField(10); // create nameField object with length of 10 
		idNumberField = new JTextField(10); 
		reportedProblemField = new JTextField(10);
		dateStartedField = new JTextField(10);
		statusField = new JTextField(10);
		priorityField = new JTextField(10);
		
		submitBtn = new JButton("Submit");
		
		
		Border innerBorder = BorderFactory.createTitledBorder("Info"); // Create Boder for the Form panel
		Border outerBorder = BorderFactory.createEmptyBorder(5, 5, 5, 5); // Set layout for the border
		setBorder(BorderFactory.createCompoundBorder(outerBorder, innerBorder));
		
		
		setLayout(new GridBagLayout());
		
		GridBagConstraints gc = new GridBagConstraints();
		
		
// Set Layout for part
		////////////////First Row////////////
		
		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.gridx = 0;
		gc.gridy = 0;
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(nameLabel, gc);
		
		gc.gridx = 1;
		gc.gridy = 0;
		gc.insets = new Insets(0, 0, 0, 0);
		gc.anchor = GridBagConstraints.LINE_START;
		add(nameField, gc);
		
		////////////////Second Row////////////
		
		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.gridy = 1;
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);		
		add(idNumberLabel, gc);
		
		gc.gridy = 1;
		gc.gridx = 1;
		gc.insets = new Insets(0, 0, 0, 0);
		gc.anchor = GridBagConstraints.LINE_START;
		add(idNumberField, gc);
		
		////////////////Third Row////////////
		
		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.gridy = 2;
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);		
		add(reportedProblemLabel, gc);
		
		gc.gridy = 2;
		gc.gridx = 1;
		gc.insets = new Insets(0, 0, 0, 0);
		gc.anchor = GridBagConstraints.LINE_START;
		add(reportedProblemField, gc);

		////////////New Row////////////////////

		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.gridy = 3;
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);		
		add(dateStartedLabel, gc);
		
		gc.gridy = 3;
		gc.gridx = 1;
		gc.insets = new Insets(0, 0, 0, 0);
		gc.anchor = GridBagConstraints.LINE_START;
		add(dateStartedField, gc);
		
		
		////////////New Row////////////////////
		
		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.gridy = 4;
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);		
		add(statusLabel, gc);
		
		gc.gridy = 4;
		gc.gridx = 1;
		gc.insets = new Insets(0, 0, 0, 0);
		gc.anchor = GridBagConstraints.LINE_START;
		add(statusField, gc);
		
		
		////////////New Row////////////////////
		
		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.gridy = 5;
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);		
		add(priorityLabel, gc);
		
		gc.gridy = 5;
		gc.gridx = 1;
		gc.insets = new Insets(0, 0, 0, 0);
		gc.anchor = GridBagConstraints.LINE_START;
		add(priorityField, gc);
		
		
		////////////New Row////////////////////
		
		gc.gridy = 6;
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		add(submitBtn, gc);
		
		
		
		
	}

}
